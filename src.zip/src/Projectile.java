
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import java.awt.Image;
public class Projectile
{
	double xpos;
	double ypos;
	int size;
	double dx;
	double dy;
	int damage;
	double range;
	double rangeCount = 0;
	//colors
	Color color = Color.black;
	
	public Projectile(double xIn, double yIn, int sizeIn, double dxIn, double dyIn, double rangeIn, int damageIn)
	{
		xpos = xIn;
		ypos = yIn;
		size = sizeIn;
		dx = dxIn;
		dy = dyIn; 
		range = rangeIn;
		damage = damageIn;
	}
	public void draw(Graphics g)
	{
		g.setColor(color);
		g.fillOval((int)xpos, (int)ypos, size, size);
	}
	public boolean move()
	{
		xpos += dx;
		ypos += dy;
		rangeCount += (dx + dy);
		if(rangeCount > range)
		{
			return true;
		}
		return false;
	}
	public double getYpos()
	{
		return ypos;
	}
	public double getXpos()
	{
		return xpos;
	}
	public double getRadius()
	{
		return size/2;
	}
	public int getDamage()
	{
		return damage;
	}

	
	
}
class Spell extends Projectile{
	String spellType;
	Image image;
	//ice effects
	static double slowAmount = 0.05;
	static double slowDuration = 300;
	//lightning effects
	static double jumpRadius = 80;
	static double lightningDamageMultiplyer = 0.2;
	//fire effects
	static double fireDamage = 0.003;
	static double fireDuration = 100;
	
	public Spell(double xIn, double yIn, int sizeIn, double dxIn, double dyIn, double rangeIn, String spellTypeIn, int damageIn, Image imageIn)
	{
		super(xIn, yIn, sizeIn, dxIn,  dyIn, rangeIn, damageIn);
		spellType = spellTypeIn;
		image = imageIn;
		setColor();
		
	}
	public void draw(Graphics g)
	{
		g.setColor(color);
		g.drawImage(image, (int)xpos, (int)ypos, null);
	}
	public void setColor()
	{
		if(spellType == "magic missle"){
			color = Color.black;
		}
			
		if(spellType == "fire"){
			color = Color.red;
		}
		
		if(spellType == "ice"){
			color = Color.CYAN;
		}
		if(spellType == "lightning"){
			color = new Color(211, 99, 237); //purpleish
		}
	}
	public boolean castSpell(Graphics g, double playerxpos, double playerypos)
	{	
		if(spellType == "shield")
		{
			return false;
		}
		if(spellType == "magic missle"){
			//effects later
		}
			
		if(spellType == "fire"){
			//effects later
		}
		
		if(spellType == "ice"){
			//effects later
		}
		
		return move();
	}
	
}


