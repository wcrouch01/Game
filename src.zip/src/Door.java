
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import java.awt.Image;
public class Door 
{
	boolean open;
	int x;
	int y;
	int width;
	int height;
	Image doorImage;
	public Door(boolean openIn, int xIn, int yIn, int widthIn, int heightIn, Image doorImageIn)
	{
		open = openIn;
		x = xIn;
		y = yIn;
		width = widthIn;
		height = heightIn;
		doorImage = doorImageIn;
	}
	public void draw(Graphics g)
	{
		if(doorImage == null)
		{
			g.setColor(Color.pink);
			g.fillRect(x, y, width, height);
		}
		else if(open)
		{
			g.drawImage(doorImage,x,y,null);
		}
		else
		{
			//g.fillRect(x, y, width, height);
		}
	}
	public boolean collisionCheck(double xIn, double yIn)
	{
		//check if IN is inside of door
		if(xIn > x && xIn < x + width && yIn > y && yIn < y + height)
		{
			return true;
		}
		
		return false;
	}
	public void changeDoor()
	{
		open = !open;
	}
}
