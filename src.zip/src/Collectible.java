
import java.awt.Color;
import java.awt.Graphics;

public class Collectible 
{
	int x;
	int y;
	int width = 40;
	int height = 40;
	Color brown = new Color(139,69,19);
	String name;
	public Collectible(int xIn, int yIn, String nameIn)
	{
		x = xIn;
		y = yIn;
		name = nameIn;
	}
	public void draw(Graphics g)
	{
		g.setColor(brown);
		g.fillRect(x, y, width, height);
		g.setColor(Color.YELLOW);
		g.drawString("?", x + width / 2, y + (height / 2));

	}
	public boolean collisionCheck(double xIn, double yIn)
	{
		//check if IN is inside of door
		if(xIn > x && xIn < x + width && yIn > y && yIn < y + height)
		{
			return true;
		}

		return false;
	}
	public String getName()
	{
		return name;
	}
}
