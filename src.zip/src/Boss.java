import java.awt.Color;
import java.awt.Image;
import java.awt.Graphics;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.swing.ImageIcon;
import java.util.ArrayList;
public class Boss {

	//playing parameter
	static final int SCREEN_WIDTH = 600;
	static final int SCREEN_HEIGHT = 800;
	static final int PLAY_WIDTH = 500;
	static final int PLAY_HEIGHT = 500;
	static final int PLAY_STARTX = 100;
	static final int PLAY_STARTY = 100;
	//characteristics
	String effect;
	Color effectColor;
	double xpos = 300;
	double ypos = 450;
	int width = 30;
	int height = 30;
	double speed = 0.2;
	double dx = 0;
	double dy = 0;
	double HP = 80;
	double maxHP = 200;
	//images
	static Image standingImage;
	static Image shootingImage;
	static Image magicMissleImage;
	Image currentImage = standingImage;
	//for projectiles
	double bspeed = 0.7;
	double original_bspeed = 0.7;
	int bsize = 10;
	int shootDelayMax = 600;
	int shootCounter = 0;
	int brange = 600;

	ArrayList<Projectile> b = new ArrayList<Projectile>();
	//running effect
	int runningCounter = 0;
	int runningCounterMax = 600;
	int movingCounter = 0;
	int movingCounterMax = 900;
	String currentAbility;
	boolean charging = false;
	boolean waveShootDone = true;
	boolean wholeShootDone = true;
	boolean shieldActive;
	int shieldTime = 1200;
	boolean upgraded = false;
	int shieldCounter = 0;
	public Boss()
	{

	}
	public boolean getShieldActive(){
		return shieldActive;
	}
	public void upgrade()
	{
		shootDelayMax = (int) (shootDelayMax * .7);
		shootCounter = 0;
		bspeed = bspeed * 1.3;
		original_bspeed = bspeed;
		speed = speed * 2;
		runningCounterMax = 400;
		runningCounter = 0;
		movingCounterMax = 600;
		movingCounter = 0;
		shieldTime = 1800;
		
	}
	
	public void draw(Graphics g)
	{
		//draw the image
		g.drawImage(currentImage, (int)xpos, (int)ypos, null);
		g.setColor(Color.black);
		g.drawString("BOSS HP", PLAY_STARTX + 200, 20);
		g.fillRect(PLAY_STARTX + 200, 50, 200, 20);
		if(HP > 0)
		{
			g.setColor(Color.red);
			g.fillRect(PLAY_STARTX + 200, 50, (int) (200 * (HP / maxHP)), 20);
		}
		if(shieldActive)
		{
			g.setColor(Color.white);
			g.drawOval((int)xpos - (width / 2), (int)ypos - (height / 4), (int)(width * 2.5), (int)(height * 2.5));
		}
		for(int i = 0; i < b.size(); i++)
		{
			b.get(i).draw(g);
			if(b.get(i).move()){
				b.remove(i);
			}
		}
	}
	public void run(Graphics g, Player p)
	{
		draw(g);
		runAbility(p);
		runningCounter++;
		movingCounter++;
		if(shieldCounter > 0)
		{
			shieldCounter--;
			if(shieldCounter == 0)
			{
				shieldActive = false;
			}
		}
		if(HP / maxHP < .25 && upgraded == false)
		{
			upgrade();
			upgraded = true;
		}
		if(runningCounter >= runningCounterMax)
		{
			runningCounter = 0;
			changeAbility();
		}
		if(movingCounter >= movingCounterMax)
		{
			movingCounter = 0;
			changeDirection();
		}
		//with the moving might be glitchy when he hits a wall, consider changing directions
		xpos += dx;
		ypos += dy;
		while(xpos <= 150)
		{
			xpos += speed;
		}
		while(xpos >= 450)
		{
			xpos -= speed;
		}
		while(ypos <= 150)
		{
			ypos += speed;
		}
		while(ypos >= 450)
		{
			ypos -= speed;
		}


	}
	public void changeAbility()
	{
		double random = Math.random();
		charging = false;
		//if upgraded, then replace the do nothing ability with wholeshoot and waveshoot

		if(random < .1)
		{
			currentAbility = "wholeShoot";
			wholeShootDone = false;
		}
		
		else if(random >= .1 && random < .2)
		{
			currentAbility = "waveShoot";
			waveShootDone = false;
		}
		
		else if(random < .5 && random >= .2)
		{
			currentAbility = "shoot";
			currentImage = shootingImage;
		}
		
		else if(random >= .5 && random < .7)
		{
			currentAbility = "charge";
			currentImage = shootingImage;
		}
		else if(random >=.7 && random < .8)
		{
			currentAbility = "shield";
			shieldActive = true;
			shieldCounter = shieldTime;
			
			
		}
		else
		{
			if(upgraded)
			{
				currentAbility = "waveShoot";
				waveShootDone = false;
			}
			else
			{
				currentImage = standingImage;
				currentAbility = "none";
			}
		}


	}
	public void runAbility(Player p)
	{
		if(currentAbility == "shoot"){
			shootCounter++;
			if(shootCounter > shootDelayMax)
			{
				shoot(p.getXpos(), p.getYpos());
				shootCounter = 0;
			}
		}
		if(currentAbility == "charge" && charging == false)
		{
			double moveAngle = Math.atan2(p.getXpos() - xpos, p.getYpos() - ypos);
			dy = Math.cos(moveAngle) * speed * 2.5;
			dx = Math.sin(moveAngle) * speed * 2.5;
			charging = true;
		}
		if(currentAbility == "waveShoot" && !waveShootDone)
		{
			waveShoot(p.getXpos(), p.getYpos());
			waveShootDone = true;
		}
		if(currentAbility == "wholeShoot" && !wholeShootDone)
		{
			wholeShoot();
			wholeShootDone = true;
		}
	}
	public void changeDirection()
	{
		if(!charging)
		{


			double random = Math.random();
			if(random < .33)
			{
				dx = speed * -1;
			}
			else if(random >= .33 && random <= .66)
			{
				dx = 0;
			}
			else
			{
				dx = speed;
			}
			random = Math.random();
			if(random < .33)
			{
				dy = speed * -1;
			}
			else if(random >= .33 && random <= .66)
			{
				dy = 0;
			}
			else
			{
				dy = speed;
			}
		}
	}
	public void shoot(double px, double py)
	{
		double angle = Math.atan2(px - xpos, py - ypos);
		double dy = Math.cos(angle) * bspeed;
		double dx = Math.sin(angle) * bspeed;
		b.add(new Projectile(xpos, ypos, bsize, dx, dy, brange, 1));
	}
	public void waveShoot(double px, double py)
	{
		double angle = Math.atan2(px - xpos, py - ypos);
		for(int i = 1; i < 4; i++)
		{
			double dy = Math.cos(angle - (i * (Math.PI / 32))) * (bspeed * .7);
			double dx = Math.sin(angle - (i * (Math.PI / 32))) * (bspeed * .7);
			b.add(new Projectile(xpos, ypos, bsize, dx, dy, brange, 1));
		}
		for(int i = 1; i < 4; i++)
		{
			double dy = Math.cos(angle + (i * (Math.PI / 32))) * (bspeed * .7);
			double dx = Math.sin(angle  + (i * (Math.PI / 32))) * (bspeed * .7);
			b.add(new Projectile(xpos, ypos, bsize, dx, dy, brange, 1));
		}
		double dy = Math.cos(angle) * (bspeed * .7);
		double dx = Math.sin(angle) * (bspeed * .7);
		b.add(new Projectile(xpos, ypos, bsize, dx, dy, brange, 1));
	}
	public void wholeShoot()
	{
		int random = (int)(Math.random() * 24);
		double angle = 0;
		for(int i = 0; i < 24; i++)
		{
			if(i == random || i == random + 1 || i == random - 1)
			{
				angle += (Math.PI / 16);
				continue;
			}
			double dy = Math.cos(angle) * (bspeed * .4);
			double dx = Math.sin(angle) * (bspeed * .4);
			b.add(new Projectile(xpos, ypos, bsize, dx, dy, brange, 1));
			angle += (Math.PI / 12);
			
		}
	}
	//check if something touches the boss (mostly player projectiles
	public boolean checkCollision(double newX, double newY, double radius)
	{
		double dx = xpos - newX;
		double dy = ypos- newY;
		double radii = (width / 2) + radius;
		if ( ( dx * dx )  + ( dy * dy ) < radii * radii ) 
		{
			return true;
		}
		return false;
	}
	//check if the boss's bullets hit something else
	public boolean checkBulletCollision(double newX, double newY, double radius)
	{
		for(int i = 0; i < b.size(); i++)
		{
			double dx = b.get(i).getXpos() - newX;
			double dy = b.get(i).getYpos() - newY;
			double radii = (b.get(i).size / 2) + radius;
			if ( ( dx * dx )  + ( dy * dy ) < radii * radii ) 
			{
				b.remove(i);
				return true;
			}

		}
		return false;
	}
	public void takeDamage(double damageIn)
	{
		HP -= damageIn;
	}
	public double getHP()
	{
		return HP;
	}

}
