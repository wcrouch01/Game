
import java.awt.Color;
import java.awt.Graphics;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.util.ArrayList;
public class Enemy 
{
	static final int SCREEN_WIDTH = 600;
	static final int SCREEN_HEIGHT = 800;
	static final int PLAY_WIDTH = 500;
	static final int PLAY_HEIGHT = 500;
	static final int PLAY_STARTX = 100;
	static final int PLAY_STARTY = 100;
	
	String type;
	String effect;
	Color effectColor;
	Image image;
	double xpos;
	double ypos;
	int width;
	int height;
	double speed;
	double HP;
	//used in spell effects
	int effectCounter = 0;
	double originalSpeed;
	double damageEffect = 0;
	//for projectile enemies
	double bspeed = 0.7;
	double original_bspeed = 0.7;
	int bsize = 10;
	int shootDelayMax = 1200;
	int shootCounter = 0;
	int brange = 600;
	

	//for projectile enemies
	ArrayList<Projectile> b = new ArrayList<Projectile>();
	public Enemy(String typeIn, String effectIn, double speedIn, int HPin)
	{
		effect = effectIn;
		setColorEffect();
		type = typeIn;
		width = 30;
		height = 30;	
		xpos = (Math.random() * 300) + PLAY_STARTX + 100;
		ypos = (Math.random() * 300) + PLAY_STARTY + 100;
		if(type == "projectile and normal")
		{
			//make everything slightly weaker
			speedIn = speedIn * 0.8;
			bspeed = 0.55;
			original_bspeed = 0.55;
			shootDelayMax = 1500;
		}
		speed = speedIn;
		originalSpeed = speed;
		HP = HPin;


	}
	public void setColorEffect()
	{
		if(effect == "ice")
		{
			effectColor = Color.CYAN;
		}
		if(effect == "fire")
		{
			effectColor = Color.RED;
		}
		if(effect == "lightning")
		{
			effectColor = new Color(211, 99, 237);
		}
	}
	public String getType()
	{
		return type;
	}
	public String getEffect()
	{
		return effect;
	}
	public boolean takeDamage(double damageIn)
	{
		HP -= damageIn;
		return (HP <= 0);
	}
	public double getHP()
	{
		return HP;
	}
	public void draw(Graphics g, Image curr)
	{
		g.setColor(Color.black);
		g.drawImage(curr, (int)xpos, (int)ypos, null);
		if(effect != "none")
		{
			g.setColor(effectColor);
			g.fillOval((int)xpos + (width / 2), (int)ypos - height, 15, 15);
		}
		if(type == "projectile" || type == "projectile and normal")
		{
			for(int i = 0; i < b.size(); i++)
			{
				b.get(i).draw(g);
				if(b.get(i).move()){
					b.remove(i);
				}
			}
		}
		
	}
	public void move(double px, double py)
	{
		if(effectCounter > 0)
		{
			effectCounter--;
			HP -= damageEffect;
			//once the counter reaches the min... reset effects back to normal
			if(effectCounter == 0)
			{
				bspeed = original_bspeed;
				speed = originalSpeed;
			}
		}
		if(type == "projectile" || type == "projectile and normal")
		{
			shootCounter++;
			if(shootCounter > shootDelayMax)
			{
				shoot(px, py);
				shootCounter = 0;
			}
		}
		if(type == "normal" || type == "projectile and normal")
		{
			if(px < xpos)
			{
				xpos -= speed;
			}
			if(px > xpos)
			{
				xpos += speed;
			}
			if(py < ypos)
			{
				ypos -= speed;
			}
			if(py > ypos)
			{
				ypos += speed;
			}
		}
	}
	public void shoot(double px, double py)
	{
		double angle = Math.atan2(px - xpos, py - ypos);
		double dy = Math.cos(angle) * bspeed;
		double dx = Math.sin(angle) * bspeed;
		b.add(new Projectile(xpos, ypos, bsize, dx, dy, brange, 1));
	}

	public boolean checkCollision(double newX, double newY, double radius)
	{
		double dx = xpos - newX;
		double dy = ypos- newY;
		double radii = (width / 2) + radius;
		if ( ( dx * dx )  + ( dy * dy ) < radii * radii ) 
		{
			return true;
		}
		return false;
	}
	public boolean checkBulletCollision(double newX, double newY, double radius)
	{
		for(int i = 0; i < b.size(); i++)
		{
			double dx = b.get(i).getXpos() - newX;
			double dy = b.get(i).getYpos() - newY;
			double radii = (b.get(i).size / 2) + radius;
			if ( ( dx * dx )  + ( dy * dy ) < radii * radii ) 
			{
				b.remove(i);
				return true;
			}
			
		}
		return false;
	}


}
