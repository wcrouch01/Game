
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.swing.ImageIcon;
import java.awt.Image;
public class Room 
{
	//screen parameters
	static final int SCREEN_WIDTH = 600;
	static final int SCREEN_HEIGHT = 800;
	static final int PLAY_WIDTH = 500;
	static final int PLAY_HEIGHT = 500;
	static final int PLAY_STARTX = 100;
	static final int PLAY_STARTY = 100;
	//room descriptions
	boolean valid;
	boolean cleared = false;
	String roomType;
	Door victoryDoor;
	//doors
	int doorDepth = 40;
	Door right;
	boolean rightDoor;
	boolean rightDoorOpen = false;
	Door top;
	boolean topDoor;
	boolean topDoorOpen = false;
	Door left;
	boolean leftDoor;
	boolean leftDoorOpen = false;
	Door bottom;
	boolean bottomDoor;
	boolean bottomDoorOpen = false;

	Boss darkWizard;
	
	ArrayList<Enemy> e = new ArrayList<Enemy>();
	int enemyDelay = 0;

	ArrayList<Collectible> c = new ArrayList<Collectible>();
	Image enemyImage;
	Image backgroundImage;
	Image doorImage;

	public Room(boolean validIn)
	{
		valid = validIn;
		roomType = "normal";
	}
	public boolean getValid()
	{
		return valid;
	}
	public void setRoomType(String in)
	{
		roomType = in;
		if(roomType == "victory")
		{
			victoryDoor = new Door(false, 300, 200, doorDepth, doorDepth, null);
		}

		if(roomType == "reward")
		{
			cleared = true;
			topDoorOpen = true;
			bottomDoorOpen = true;
			rightDoorOpen = true;
			leftDoorOpen = true;

		}
		if(roomType == "boss")
		{
			darkWizard = new Boss();
		}

	}

	public void addCollectible(Collectible cIn){
		c.add(cIn);
	}

	public String getRoomType()
	{
		return roomType;
	}
	public boolean getCleared()
	{
		return cleared;
	}
	public void setCleared()
	{
		cleared = true;
	}
	public void setEnemyDelay()
	{
		enemyDelay = 400;
	}
	public void setDoors(boolean r, boolean t, boolean l, boolean b, Image backgroundImageIn, Image doorImageIn)
	{
		backgroundImage = backgroundImageIn;
		doorImage = doorImageIn;
		rightDoor = r;
		if(r){
			doorImage = doorImage.getScaledInstance(doorDepth, (int)(PLAY_HEIGHT * .2), 0);
			right = new Door(rightDoorOpen, PLAY_STARTX + PLAY_WIDTH - (doorDepth), (int)(PLAY_STARTY + (PLAY_HEIGHT * .4)), doorDepth, (int)(PLAY_HEIGHT * .2), doorImage);
		}
		topDoor = t;
		if(t){
			doorImage = doorImage.getScaledInstance( (int)(PLAY_WIDTH * .2), doorDepth, 0);
			top = new Door(topDoorOpen, (int)(PLAY_STARTX + (PLAY_WIDTH * .4)), PLAY_STARTY, (int)(PLAY_WIDTH * .2), doorDepth, doorImage);
		}
		leftDoor = l;
		if(l){
			doorImage = doorImage.getScaledInstance(doorDepth, (int)(PLAY_HEIGHT * .2), 0);
			left = new Door(leftDoorOpen, PLAY_STARTX, (int)(PLAY_STARTY + (PLAY_HEIGHT * .4)), doorDepth, (int)(PLAY_HEIGHT * .2), doorImage);
		}
		bottomDoor = b;
		if(b){
			doorImage = doorImage.getScaledInstance( (int)(PLAY_WIDTH * .2), doorDepth, 0);
			bottom = new Door(bottomDoorOpen, (int)(PLAY_STARTX + (PLAY_WIDTH * .4)), PLAY_STARTY + PLAY_HEIGHT - (doorDepth), (int)(PLAY_WIDTH * .2), doorDepth, doorImage);
		}

	}
	public void drawRoom(Graphics g, Player p, Image curr)
	{
		double px = p.getXpos();
		double py = p.getYpos();

		//g.drawRect(PLAY_STARTX, PLAY_STARTX, PLAY_WIDTH, PLAY_HEIGHT);
		//g.setColor(Color.MAGENTA);
		g.drawImage(backgroundImage, PLAY_STARTX, PLAY_STARTY, null);
		if(rightDoor)
		{
			right.draw(g);
		}
		if(leftDoor)
		{
			left.draw(g);
		}
		if(topDoor)
		{
			top.draw(g);
		}
		if(bottomDoor)
		{
			bottom.draw(g);
		}
		if(roomType == "victory" && cleared)
		{
			victoryDoor.draw(g);
		}

		if(roomType == "reward" && cleared && c != null && c.size() > 0)
		{
			c.get(0).draw(g);
		}
		if(roomType == "boss" && darkWizard != null)
		{
			darkWizard.run(g, p);
			if(darkWizard.getHP() <= 0)
			{
				darkWizard = null;
			}
		}

		//draw enemies
		if(enemyDelay > 0)
		{
			enemyDelay--;
		}
		for(int i = 0; i < e.size(); i++)
		{
			if(e.get(i).getHP() <= 0)
			{
				e.remove(i);
				i = 0; //bring the loop back to the start
			}
			if(e.size() == 0)
			{
				break;
			}
			e.get(i).draw(g, curr);
			if(enemyDelay <= 0)
			{
				e.get(i).move(px, py);
			}
		}
		//if all enemies are dead, open the doors
		if(cleared == false)
		{
			if(e.size() == 0 && darkWizard == null)
			{
				//purpose of cleared is so that we only go in here once
				if(rightDoor)
				{
					rightDoorOpen = true;
					right.changeDoor();
				}
				if(leftDoor){
					leftDoorOpen = true;
					left.changeDoor();
				}
				if(topDoor){
					topDoorOpen = true;
					top.changeDoor();
				}
				if(bottomDoor){
					bottomDoorOpen = true;
					bottom.changeDoor();
				}
				cleared = true;
			}
		}
	}

	public boolean collectibleCollision(double xIn, double yIn)
	{
		if(cleared && c.size() > 0)
		{
			if(c.get(0).collisionCheck(xIn, yIn)){
				return true;
			}

		}
		return false;
	}
	public String getCollectibleName()
	{
		if(cleared && c.size() > 0)
		{
			String temp = c.get(0).getName();
			c.remove(0);
			return temp;
		}
		return null;
	}

	public String doorCollision(double xIn, double yIn)
	{
		if(cleared && roomType == "victory")
		{
			if(victoryDoor.collisionCheck(xIn, yIn))
			{
				return "victory";
			}
		}

		if(leftDoor && leftDoorOpen)
		{
			if(left.collisionCheck(xIn, yIn))
			{
				return "left";
			}
		}
		if(rightDoor && rightDoorOpen)
		{

			if(right.collisionCheck(xIn, yIn))
			{
				return "right";
			}
		}
		if(topDoor && topDoorOpen)
		{
			if(top.collisionCheck(xIn, yIn))
			{
				return "top";
			}
		}
		if(bottomDoor && bottomDoorOpen)
		{

			if(bottom.collisionCheck(xIn, yIn))
			{
				return "bottom";
			}
		}
		return null;
	}
	public void createEnemies(int minE, int maxE, double speedE, int HP)
	{
		String tempName = "normal";
		String effect;
		double ratio;
		
		int eSize = (int)(Math.random() * maxE + minE);
		for(int i = 0; i < eSize; i++)
		{
			ratio = Math.random();
			effect = selectEffect();
			if(ratio < .45)
			{
				tempName = "normal";
			}
			else if(ratio >= .45 && ratio <= .80)
			{
				tempName = "projectile";
			}
			else
			{
				tempName = "projectile and normal";
			}
			e.add(new Enemy(tempName, effect,speedE, HP));
		}
	}
	public String selectEffect()
	{
		double ratio = Math.random();
		if(ratio < .85)
		{
			return "none";
		}
		else if(ratio >= .85 && ratio < .9)
		{
			return "fire";
		}
		else if(ratio >= .9 && ratio < .95)
		{
			return "ice";
		}
		else
		{
			return "lighting";
		}
	}
	//check for collisions between player spells and enemies
	public void spellsToEnemies(ArrayList<Spell> b)
	{
		if(cleared == false){

			for(int i = 0; i < b.size(); i++)
			{
				if(darkWizard != null)
				{
					if(darkWizard.getShieldActive() == false && darkWizard.checkCollision(b.get(i).getXpos(), b.get(i).getYpos(), b.get(i).getRadius()))
						{
							darkWizard.takeDamage(b.get(i).getDamage());
							b.remove(i);
							return;
						}
					
				}
				for(int j = 0; j < e.size(); j++)
				{
					
					if(e.get(j).checkCollision(b.get(i).getXpos(), b.get(i).getYpos(), b.get(i).getRadius()))
					{
						if(b.get(i).spellType.equals(e.get(j).getEffect()))
						{
							continue;
						}
						
						else if(e.get(j).takeDamage(b.get(i).getDamage()))
						{
							e.remove(j);
						}
						else
						{
							spellEffect(b.get(i).spellType, b.get(i), j);
						}
						b.remove(i);

						return; //just check again at next tick
					}
				}
			}
		}
	}
	
	//check for collisions between enemies and player
	public boolean playerToEnemies(Player p, boolean shieldActive)
	{
		if(cleared == false)
		{
			for(int i = 0; i < e.size(); i++)
			{
				if(e.get(i).getType() == "projectile")
				{
					if(shieldActive)
					{
						continue;
					}
					if(e.get(i).checkBulletCollision(p.getXpos(), p.getYpos(), p.getRadius()))
					{
						return true;
					}
				}
				else
				{
					if(e.get(i).checkCollision(p.getXpos(), p.getYpos(), p.getRadius()))
					{
						return true;
					}
				}
			}
		}
		return false;
	}
	public boolean BossToPlayer(Player p, boolean shieldActive)
	{
		if(darkWizard.checkCollision(p.getXpos(), p.getYpos(), p.getRadius()))
		{
			return true;
		}
		if(darkWizard.checkBulletCollision(p.getXpos(), p.getYpos(), p.getRadius()) && !shieldActive)
		{
			return true;
		}
		return false;
	}
	public void spellEffect(String spellName, Spell b, int eIndex)
	{
		//ice slows enemies for a period of time
		if(spellName == "ice")
		{
			if(e.get(eIndex).getEffect() == "ice")
			{
				return;
			}
			e.get(eIndex).speed = Math.abs(e.get(eIndex).speed - Spell.slowAmount);	
			e.get(eIndex).bspeed = Math.abs(e.get(eIndex).bspeed - Spell.slowAmount);	
			e.get(eIndex).effectCounter = (int) Spell.slowDuration;
		}
		//lighting damages one other enemy within the lightning radius
		if(spellName == "lightning")
		{
			if(e.get(eIndex).getEffect() == "lightning")
			{
				return;
			}
			for(int i = 0; i < eIndex; i++)
			{
				if(i != eIndex && e.get(i).checkCollision(e.get(eIndex).xpos,e.get(eIndex).ypos, Spell.jumpRadius) && e.get(eIndex).getType() != "lightning")
				{
					if(e.get(i).takeDamage(b.getDamage() * Spell.lightningDamageMultiplyer))
					{
						e.remove(i);
						return; //only jump to one
					}
				}
			}
		}
		if(spellName == "fire")
		{
			if(e.get(eIndex).getEffect() == "fire")
			{
				return;
			}
			e.get(eIndex).damageEffect = Spell.fireDamage;
			e.get(eIndex).effectCounter = (int) Spell.fireDuration;
		}
	}

}
