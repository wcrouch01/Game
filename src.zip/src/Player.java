import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;

import java.util.Random;
import java.awt.Image;
import java.awt.Toolkit;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.net.URL;
public class Player extends JPanel//implements gameObject
{
	//screen finals
	static int DELAY_IN_MILLISEC = (100/60);
	static final int SCREEN_WIDTH = 800;
	static final int SCREEN_HEIGHT = 800;
	static final int PLAY_WIDTH = 500;
	static final int PLAY_HEIGHT = 500;
	static final int PLAY_STARTX = 100;
	static final int PLAY_STARTY = 100;
	//movement
	public boolean RIGHT = false;
	public boolean LEFT = false;
	public boolean UP = false;
	public boolean DOWN = false;
	//display info
	double maxHP = 8;
	double HP = 8;
	double maxMana = 1000;
	double mana = 1000;
	double manaRecharge = 0.6;
	double manaDrain = 100;
	
	String displayString = null;
	int displayCounter = 600;
	int displayMaxCounter = 600;
	//player info
	double xpos = 300;
	double ypos = 300;
	int size = 25;
	double speed = 1;
	//projectile info
	ArrayList<Spell> b = new ArrayList<Spell>();
	int bsize = 10;
	double bspeed = 1;
	int brange = 400;
	int damage = 4;
	int fireRate = 5;
	int fireRateCounter = 0;
	int maxFireRate = 100;
	//spells
	ArrayList<String> spells = new ArrayList<String>();
	int currentSpell = 0;
	//shield
	boolean shieldActive = false;
	double shieldDrain = 1.6;
	//health delay after being hit
	int damageDelay = 0;


	Image standingImage;
	Image shootingImage;
	int shootingCounter = 0;
	int shootingCounterMax = 120;
	Image iceImage;
	Image fireImage;
	Image lightningImage;
	Image magicMissleImage;
	Image shieldImage;
	ArrayList<Image> spellImages = new ArrayList<Image>();
	boolean shooting = false;
	public Player() throws IOException
	{
		spells.add("magic missle");
		//spells.add("shield");
		spells.add("fire");
		spells.add("ice");
		spells.add("lightning");
		loadImages();
		
	}
	public void loadImages() throws IOException
	{
		standingImage = ImageIO.read(new File("./resources/StandingWizard.png"));
		standingImage = standingImage.getScaledInstance(40, 40, 0);
		shootingImage = ImageIO.read(new File("./resources/ShootingWizard.png"));
		shootingImage = shootingImage.getScaledInstance(40, 40, 0);
		
		magicMissleImage = ImageIO.read(new File("./resources/MagicMissle.png"));
		magicMissleImage = magicMissleImage.getScaledInstance(20, 20, 0);
		spellImages.add(magicMissleImage);
		Boss.magicMissleImage = magicMissleImage;
		
		//shieldImage = ImageIO.read(new File("./resources/shield.png"));
		//shieldImage = shieldImage.getScaledInstance(20, 20, 0);
		//spellImages.add(shieldImage);
		
		fireImage = ImageIO.read(new File("./resources/Fire.png"));
		fireImage = fireImage.getScaledInstance(20, 20, 0);
		spellImages.add(fireImage);
		
		iceImage = ImageIO.read(new File("./resources/Ice.png"));
		iceImage = iceImage.getScaledInstance(20, 20, 0);
		spellImages.add(iceImage);
		
		lightningImage = ImageIO.read(new File("./resources/Lightning.png"));
		lightningImage = lightningImage.getScaledInstance(20, 20, 0);
		spellImages.add(lightningImage);
		
		
	}
	
	public void drawPlayer(Graphics g)
	{

		g.setColor(Color.black);
		if(displayString != null)
		{
			g.drawString(displayString, 300, 300);
			displayCounter--;
			if(displayCounter == 0)
			{
				displayString = null;
				displayCounter = displayMaxCounter;
			}
		}
		if(!shooting){
			g.drawImage(standingImage, (int)xpos, (int)ypos, null);
		}
		if(shooting){
			g.drawImage(shootingImage, (int)xpos, (int)ypos, null);	
		}
		if(shootingCounter > 0)
		{
			shootingCounter--;
		}
		else
		{
			shooting = false;
		}

		g.fillRect(PLAY_STARTX, 20, 100, 20);
		g.fillRect(PLAY_STARTX, 50, 100, 20);
		//draw health and mana
		if(HP > 0)
		{
			g.setColor(Color.red);
			g.fillRect(PLAY_STARTX, 20, (int) (100 * (HP / maxHP)), 20);
		}
		if(mana > 0)
		{
			g.setColor(Color.blue);
			g.fillRect(PLAY_STARTX, 50, (int) (100 * (mana / maxMana)), 20);
		}
		//draw all of the spell selects
		g.setColor(Color.gray);
		for(int i = 0; i < spells.size(); i++){
			if(i != currentSpell){
				g.drawOval(PLAY_STARTX + (i * 40), PLAY_STARTY + PLAY_HEIGHT + 40, 20, 20);
				g.drawImage(spellImages.get(i), PLAY_STARTX + (i * 40), PLAY_STARTY + PLAY_HEIGHT + 40, null);}
			else{
				g.drawOval(PLAY_STARTX + (i * 40), PLAY_STARTY + PLAY_HEIGHT + 40, 25, 25);
				g.drawImage(spellImages.get(i), PLAY_STARTX + (i * 40), PLAY_STARTY + PLAY_HEIGHT + 40, null);
			}
		}
		//charge mana
		if(mana < maxMana)
		{
			mana+= manaRecharge;
		}
		//draw holding spells
		if(shieldActive)
		{
			g.setColor(Color.white);
			g.drawOval((int)xpos - (size / 2), (int)ypos - (size / 4), (int)(size * 2.5), (int)(size * 2.5));
			mana -= shieldDrain;
		}
		//if player was hit count down the timer
		if(damageDelay > 0)
		{
			damageDelay--;
		}
		//manage fire rate
		if(fireRateCounter <= maxFireRate)
		{
			fireRateCounter += fireRate;
		}
		//loop through everything to do with projectile array
		bloop(g);
	}
	public void bloop(Graphics g)
	{
		if(b.size() == 0){
			return;
		}

		for(int i = 0; i < b.size(); i++){
			b.get(i).draw(g);
			if(b.get(i).castSpell(g, xpos, ypos)){
				b.remove(i);
			}


		}
	}
	public boolean roomInteract(Room curr){
		curr.spellsToEnemies(b);
		if(damageDelay == 0)
		{
			if(curr.playerToEnemies(this, shieldActive))
			{
				HP--;
				damageDelay = 1000;
				if(HP == 0)
				{
					return true;
				}
			}
			if(curr.darkWizard != null && curr.BossToPlayer(this, shieldActive))
			{
				HP--;
				damageDelay = 1000;
				if(HP == 0)
				{
					return true;
				}
			}
		}
		return false;
	}
	public void setDirection(String direction, boolean b)
	{
		
		if(direction == "r")
		{
			RIGHT = b;
		}
		if(direction == "l")
		{
			LEFT = b;
		}
		if(direction == "u")
		{
			UP = b;
		}
		if(direction == "d")
		{
			DOWN = b;
		}
	}
	public void movePlayer()
	{
		if(RIGHT)
		{
			xpos += speed;
			while(xpos > PLAY_STARTX + PLAY_WIDTH - size)
			{
				xpos -= speed;
			}
		}
		if(LEFT)
		{
			xpos -= speed;
			while(xpos < PLAY_STARTX)
			{
				xpos += speed;
			}
		}
		if(UP)
		{
			ypos -= speed;
			while(ypos < PLAY_STARTY)
			{
				ypos += speed;
			}
		}
		if(DOWN)
		{
			ypos += speed;
			while(ypos > PLAY_STARTY + PLAY_HEIGHT - size)
			{
				ypos -= speed;
			}
		}
	}
	public void Shield()
	{
		if(mana <= 65)
		{
			shieldActive = false;
		}
			shieldActive = true;
			
	}
	public void shoot(String direction)
	{
		shooting = true;
		shootingCounter = shootingCounterMax;
		
			if(mana <= manaDrain)
			{
				return;
			}

			if(fireRateCounter < maxFireRate)
			{	
				return;
			}
			mana -= manaDrain;
			fireRateCounter = 0;
			if(direction == "r")
			{
				b.add(new Spell(xpos, ypos, bsize, bspeed, 0, brange, spells.get(currentSpell), damage, spellImages.get(currentSpell)));
			}
			if(direction == "l")
			{
				b.add(new Spell(xpos, ypos, bsize, -bspeed, 0, brange, spells.get(currentSpell), damage,  spellImages.get(currentSpell)));
			}
			if(direction == "u")
			{
				b.add(new Spell(xpos, ypos, bsize, 0, -bspeed, brange, spells.get(currentSpell), damage,  spellImages.get(currentSpell)));
			}
			if(direction == "d")
			{
				b.add(new Spell(xpos, ypos, bsize, 0, bspeed, brange, spells.get(currentSpell), damage,  spellImages.get(currentSpell)));
			}
		
	}
	public void selectSpell(int i)
	{
		//cancel all holding spells
		if(shieldActive)
		{
			shieldActive = false;
		}
		//change spells
		currentSpell += i;
		if(currentSpell > spells.size() - 1)
		{
			currentSpell = 0;
		}
		if(currentSpell < 0)
		{
			currentSpell = spells.size() - 1;
		}
	}
	public void cancelSpells()
	{
		shooting = false;
		
	}
	public void cancelShield()
	{
		shieldActive = false;
	}
	public void displayMoving(Graphics g)
	{
		//g.drawString("Right = "+ RIGHT, 650, 150);
		//g.drawString("Left = "+ LEFT, 650, 200);
		//g.drawString("Up = "+ UP, 650, 250);
		//g.drawString("Down = "+ DOWN, 650, 300);
	}
	public double getXpos()
	{
		return xpos;
	}
	public double getYpos()
	{
		return ypos;
	}
	public double getRadius()
	{
		return (double) (size / 2);
	}
	public void enterRoom(String enteredFrom)
	{
		//receive which door they entered in the previous room, 
		//set player to correct position
		damageDelay = 1000;
		if(enteredFrom == "right")
		{
			xpos = PLAY_STARTX + 2*size;
		}
		if(enteredFrom == "left")
		{
			xpos = PLAY_STARTX + PLAY_WIDTH - 2*size;
		}
		if(enteredFrom == "top")
		{
			ypos = PLAY_STARTY + PLAY_HEIGHT - 2*size;
		}
		if(enteredFrom == "bottom")
		{
			ypos = PLAY_STARTY + 2*size;
		}
	}
	//method for dealing with adding collectible items to the character
	public void addItem(String name)
	{
		if(name == null)
		{
			return;
		}
		if(name == "HealthUP")
		{
			HP += 1;
			maxHP += 1;
		}
		if(name == "DamageUP")
		{
			damage += 1;
		}
		if(name == "ManaUP")
		{
			maxMana += 100;
		}
		if(name == "FireRateUP")
		{
			fireRate += 5;
		}
		if(name == "healthUP + full Heal")
		{
			maxHP += 1;
			HP = maxHP;
		}
		if(name == "SpeedUP")
		{
			speed += 0.2;
		}
		if(name == "Heal")
		{
			HP = maxHP;
		}
		if(name == "fireUpgrade")
		{
			Spell.fireDamage = Spell.fireDamage * 2;
			Spell.fireDuration = Spell.fireDuration * 1.5;
		}
		if(name == "iceUpgrade")
		{
			Spell.slowAmount = Spell.slowAmount * 2;
			Spell.slowDuration = Spell.slowDuration * 1.5;
		}
		if(name == "lightningUpgrade")
		{
			Spell.jumpRadius = Spell.jumpRadius * 2;
			Spell.lightningDamageMultiplyer = Spell.lightningDamageMultiplyer * 2;
		}
		if(name == "shieldUpgrade")
		{
			shieldDrain -= 0.2;
		}
		if(name == "mana Recharge Upgrade")
		{
			manaRecharge += 0.15;
		}
		if(name == "mana Drain Down")
		{
			shieldDrain -= 0.05;
			manaDrain -= 20;
		}
		if(name == "superUpgrade (All Stats Up)")
		{
			speed += 0.1;
			fireRate += 3;
			maxMana += 60;
			HP += 1;
			maxHP += 1;
			damage += 1;
			manaRecharge += 0.05;
			shieldDrain -= 0.1;
		}
		displayString = name;
		
	}





}

