
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.swing.ImageIcon;
import java.awt.Image;
public class Level 
{
	//drawing formats
	static final int SCREEN_WIDTH = 600;
	static final int SCREEN_HEIGHT = 800;
	static final int PLAY_WIDTH = 500;
	static final int PLAY_HEIGHT = 500;
	static final int PLAY_STARTX = 100;
	static final int PLAY_STARTY = 100;
	//level info
	Room grid[][];
	int levelSize;
	int currentX;
	int currentY;
	String levelType;
	Color backGround; //will be an image eventually
	Image backgroundImage;
	Image doorImage;

	//enemy info
	int minE;
	int maxE;
	double speedE;
	int HPE;
	
	//collectibles
	int numCollectibles;
	String c[];
	int cCounter = 0;
	
	public Level(int levelSizeIn, String in, Color cIn, int numCollectiblesIn, Image bgIn, Image doorIn)
	{
		levelSize = levelSizeIn;
		levelType = in;
		grid = new Room[levelSize][levelSize];
		backGround = cIn;
		backgroundImage = bgIn;
		doorImage = doorIn;
		numCollectibles = numCollectiblesIn;
		c = new String[numCollectibles];
	}
	public int getNumCollectibles()
	{
		return numCollectibles;
	}
	public void setCollectible(String in)
	{
		c[cCounter] = in;
		cCounter++;
	}
	//temporary way to set up first level
	public void setUpLevel()
	{
		
		for(int i = 0; i < levelSize; i++)
		{
			for(int j = 0; j < levelSize; j++)
			{
				/*
				//we want all border rooms to be false so we don't have to worry about array out of bounds
				if(i != 0 || j != 0 || i != levelSize - 1 || j != levelSize - 1){
				grid[i][j] = new Room(true);
				}
				else{
					grid[i][j] = new Room(false);
				}
				 */
				grid[i][j] = new Room(false);
			}
		}
		if(levelType == "forest")
		{
			//enemies
			minE = 1;
			maxE = 3;
			speedE = 0.1;
			HPE = 2;
			//starting spot
			currentX = 4;
			currentY = 4;
			
			grid[4][4] = new Room(true);
			grid[4][4].setRoomType("starting");
			//path to finish
			grid[3][4] = new Room(true);
			grid[3][3] = new Room(true);
			grid[3][2] = new Room(true);
			grid[3][1] = new Room(true);
			grid[2][1] = new Room(true);
			grid[1][1] = new Room(true);
			grid[1][1].setRoomType("victory");
			//side distraction rooms
			grid[5][4] = new Room(true);
			grid[5][5] = new Room(true);
			grid[6][5] = new Room(true);
			grid[6][5].setRoomType("reward");
			grid[6][5].addCollectible(new Collectible(400,400,c[0]));
			grid[5][6] = new Room(true);
			grid[5][6].setRoomType("reward");
			grid[5][6].addCollectible(new Collectible(400,400,c[1]));
			grid[4][1] = new Room(true);
		}
		if(levelType == "graveyard")
		{
			minE = 2;
			maxE = 5;
			HPE = 2;
			speedE = 0.14;
			currentX = 3;
			currentY = 3;
			//starting room
			grid[3][3] = new Room(true);
			grid[3][3].setRoomType("starting");
			//bad path
			grid[2][3] = new Room(true);
			grid[2][2] = new Room(true);
			grid[2][1] = new Room(true);
			grid[2][1].setRoomType("reward");
			grid[2][1].addCollectible(new Collectible(400,400,c[0]));
			//bad path
			grid[4][3] = new Room(true);
			grid[5][3] = new Room(true);
				//bad subpath
				grid[5][2] = new Room(true);
				grid[5][1] = new Room(true);
				grid[4][1] = new Room(true);
				grid[6][1] = new Room(true);
				grid[6][1].setRoomType("reward");
				grid[6][1].addCollectible(new Collectible(400,400,c[1]));
				//bad subpath
				grid[6][3] = new Room(true);
				grid[7][3] = new Room(true);
				grid[8][3] = new Room(true);
				grid[8][2] = new Room(true);
				grid[8][4] = new Room(true);
				grid[8][4].setRoomType("reward");
				grid[8][4].addCollectible(new Collectible(400,400,c[2]));
			//good path
			grid[3][4] = new Room(true);
			grid[3][5] = new Room(true);
			grid[4][5] = new Room(true); // bad room
			grid[3][6] = new Room(true);
			grid[2][6] = new Room(true);
			grid[1][6] = new Room(true); // bad room
			grid[2][7] = new Room(true);
			grid[2][8] = new Room(true);
			grid[2][8].setRoomType("victory");
		}
		if(levelType == "town")
		{
			minE = 3;
			maxE = 6;
			HPE = 3;
			speedE = 0.16;
			currentX = 4;
			currentY = 4;
			grid[4][4] = new Room(true);
			grid[4][4].setRoomType("starting");
				//path 1
				grid[4][5] = new Room(true);
				grid[4][6] = new Room(true);
					//path 1a
					grid[3][6] = new Room(true);
					grid[2][6] = new Room(true);
					grid[1][6] = new Room(true);
					grid[1][6].setRoomType("reward");
					grid[1][6].addCollectible(new Collectible(400,400,c[0]));
					//path 1b
					grid[5][6] = new Room(true);
					grid[6][6] = new Room(true);
					grid[6][7] = new Room(true);
				//path 2
				grid[4][3] = new Room(true);
				grid[4][2] = new Room(true);
				grid[3][2] = new Room(true);
				//path 3
				grid[3][4] = new Room(true);
				grid[2][4] = new Room(true);
				grid[1][4] = new Room(true);
				grid[1][3] = new Room(true);
				grid[2][3] = new Room(true);
				grid[1][2] = new Room(true);
				grid[1][1] = new Room(true);
				grid[1][1].setRoomType("reward");
				grid[1][1].addCollectible(new Collectible(400,400,c[1]));
				//path 4
				grid[5][4] = new Room(true);
				grid[6][4] = new Room(true);
				grid[7][4] = new Room(true);
					//path 4a
					grid[7][3] = new Room(true);
					grid[7][2] = new Room(true);
					grid[7][2].setRoomType("reward");
					grid[7][2].addCollectible(new Collectible(400,400,c[1]));
					//path 4b (victory path)
					grid[8][4] = new Room(true);
					grid[8][5] = new Room(true);
					grid[8][6] = new Room(true);
					grid[8][7] = new Room(true);
					grid[8][8] = new Room(true);
					grid[8][8].setRoomType("victory");
					
					
		}
		if(levelType == "castle")
		{
			minE = 4;
			maxE = 8;
			HPE = 4;
			speedE = 0.18;
			currentX = 1;
			currentY = 1;
			grid[1][1] = new Room(true);
			grid[1][1].setRoomType("starting");
			//path straight down
			grid[1][2] = new Room(true);
			grid[1][3] = new Room(true);
				//side room
				grid[2][3] = new Room(true);
				grid[2][3].setRoomType("reward");
				grid[2][3].addCollectible(new Collectible(400,400,c[0]));
			grid[1][4] = new Room(true);
			grid[1][5] = new Room(true);
			grid[1][6] = new Room(true);
				//side room
				grid[1][7] = new Room(true);
			//path right
			grid[2][6] = new Room(true);
			grid[3][6] = new Room(true);
			grid[4][6] = new Room(true);
				//small side path
				grid[4][7] = new Room(true);
				grid[4][8] = new Room(true);
				grid[4][8].setRoomType("reward");
				grid[4][8].addCollectible(new Collectible(400,400,c[1]));
			grid[5][6] = new Room(true);
			grid[6][6] = new Room(true);
			grid[7][6] = new Room(true);
				//small side room
				grid[7][7] = new Room(true);
			grid[8][6] = new Room(true);
			//path straight up from 6,6
			grid[6][5] = new Room(true);
			grid[6][4] = new Room(true);
			grid[6][3] = new Room(true);
			grid[6][2] = new Room(true);
			grid[6][1] = new Room(true);
				//path left from 6,1
				grid[5][1] = new Room(true);
				grid[4][1] = new Room(true);
				grid[3][1] = new Room(true);
				grid[3][1].setRoomType("reward");
				grid[3][1].addCollectible(new Collectible(400,400,c[2]));
				//path right from 6,1
				grid[7][1] = new Room(true);
				grid[8][1] = new Room(true);
				grid[8][1].setRoomType("reward");
				grid[8][1].addCollectible(new Collectible(400,400,c[3]));
			//path right from 6,3
			grid[7][3] = new Room(true);
			grid[8][3] = new Room(true);
			grid[9][3] = new Room(true);
				//side room
				grid[9][4] = new Room(true);
			//square shape with [9,3] as bottom left corner
			grid[10][3] = new Room(true);
			grid[10][2] = new Room(true);
			grid[9][2] = new Room(true);
			grid[10][1] = new Room(true);
			grid[10][1].setRoomType("victory");
		}
		if(levelType == "final")
		{
			minE = 0;
			maxE = 0;
			HPE = 0;
			speedE = 0;
			currentX = 3;
			currentY = 1;
			grid[3][1] = new Room(true);
			grid[3][1].setRoomType("starting");
			grid[3][2] = new Room(true);
			grid[3][2].setRoomType("reward");
			grid[3][2].addCollectible(new Collectible(400,400,"heal"));
			grid[3][3] = new Room(true);
			grid[3][3].setRoomType("boss");
			grid[3][4] = new Room(true);
			grid[3][4].setRoomType("victory");
		}
	}
	public void createDoors()
	{

		//ignore border rooms (so don't touch first and last in array
		for(int i = 1; i < levelSize - 1; i++)
		{
			for(int j = 1; j < levelSize - 1; j++)
			{
				if(grid[i][j].getValid()) {
					if(grid[i][j].getRoomType() == "normal")
					{
						grid[i][j].createEnemies(minE, maxE, speedE, HPE);
					}
					boolean l = false;
					boolean r = false;
					boolean t = false;
					boolean b = false;
					//check top
					if(grid[i - 1][j].getValid())
					{
						l = true;
					}
					//check left
					if(grid[i][j - 1].getValid())
					{
						t = true;
					}
					//check right
					if(grid[i][j + 1].getValid())
					{
						b = true;
					}
					//check bottom
					if(grid[i + 1][j].getValid())
					{
						r = true;
					}
					grid[i][j].setDoors(r, t, l, b, backgroundImage, doorImage);
				}

			}
		}
	}
	public Room getcurrentRoom(){
		return grid[currentX][currentY];
	}
	public void drawCurrentRoom(Graphics g, Player p, Image curr)
	{
		g.setColor(backGround);
		g.fillRect(PLAY_STARTX, PLAY_STARTX, PLAY_WIDTH, PLAY_HEIGHT);
		g.setColor(Color.black);
		grid[currentX][currentY].drawRoom(g, p, curr);
	}
	public String doorCollisionR(double xIn, double yIn)
	{
		String doorInteract = grid[currentX][currentY].doorCollision(xIn, yIn);
		if(doorInteract == null)
		{
			return null;
		}
		if(doorInteract == "right")
		{
			currentX += 1;
			return doorInteract;
		}
		if(doorInteract == "left")
		{
			currentX -= 1;
			return doorInteract;
		}
		if(doorInteract == "top")
		{
			currentY -= 1;
			return doorInteract;
		}
		if(doorInteract == "bottom")
		{
			currentY += 1;
			return doorInteract;
		}
		return doorInteract;
	}
}
