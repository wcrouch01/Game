import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.Action;
/*
import javax.swing.JFrame;
import javafx.scene.image.*;
import javafx.scene.paint.*; 
import java.awt.Container;
import java.awt.EventQueue;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
*/
import javax.swing.*;
import java.awt.Image;
import java.io.*;
import java.util.*;
//import javax.swing.ImageIcon;
//import java.awt.image.ImageObserver; 
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.*;



/*TO DO
 * 
1. figure out why it flickers on windows
2. spell upgrades
*/

public class WizardGame extends Canvas
implements  ActionListener//, ImageObserver//, MouseListener
{
	//keyboard focus
	static KeyboardFocusManager kp;
	//levels
	ArrayList<Level> areas = new ArrayList<Level>();
	int areasCounter = 0;
	
	//variables
	Player p;
	Level currentLevel;
	ArrayList<String> collection = new ArrayList<String>();
	boolean ALIVE = true;
	boolean levelComplete = false;
	static int DELAY_IN_MILLISEC = (100 / 60);
	static final int SCREEN_WIDTH = 800;
	static final int SCREEN_HEIGHT = 800;
	static final int PLAY_WIDTH = 500;
	static final int PLAY_HEIGHT = 500;
	static final int PLAY_STARTX = 100;
	static final int PLAY_STARTY = 100;
	static int timer = 0;
	static JFrame f;
	//static KeyListener kl[];

	//running flags
	boolean setUP = false;
	String roomChange = null;

	//key flags
	boolean up;
	boolean down;
	boolean right;
	boolean left;
	boolean rarrow;
	boolean uarrow;
	boolean larrow;
	boolean darrow;
	boolean spellright;
	boolean spellLeft;
	boolean spacebar = false;
	//arena pictures
	Image forestImage;
	Image hedgeImage;
	Image graveyardImage;
	Image gravedoorImage;
	Image townImage;
	Image townDoorImage;
	Image towerImage;
	Image towerDoorImage;
	
	//enemy pictures
	Image currentImage;
	ArrayList<Image> enemyImages = new ArrayList<Image>();
	Image zombieImage;
	Image skeletonImage;
	Image barbarianImage;
	Image knightImage;
	Color brownish = new Color(219, 145, 54);
	
	//boss picture
	Image dstandingImage;
	Image dshootingImage;

	WizardGame aKeyListener;
	static JPanel panel;
	 static int condition = JComponent.WHEN_IN_FOCUSED_WINDOW;
     static InputMap inputMap;
     static ActionMap actionMap;
	public static void main(String[] args) throws IOException{
		panel = new JPanel(); 
		//panel.setFocusable(true);
		//panel.addFocusListener(null);
		panel.setVisible(true);
		 kp = KeyboardFocusManager.getCurrentKeyboardFocusManager();
		f = new JFrame();
		WizardGame wg = new WizardGame();
		f.add(wg);
		f.setVisible(true);
		f.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setFocusableWindowState(true);
		//f.setAutoRequestFocus(true);
		//wg.setFocusable(true);
	
		

		//wg.addFocusListener(null);
		//kl = wg.getKeyListeners();

		//wg.setFocusable(true);
		//f.setFocusable(true);
		
		 
		

	}
	public WizardGame() throws IOException{
		setSize(800, 600);
		setVisible(true);
		p = new Player();
		keyAction.p = p;
		f.getContentPane().add(panel);
		inputMap = panel.getInputMap(condition);
	     actionMap = panel.getActionMap();
		addKeyBindings();
		setUpCollection();
		loadImages();
		
		
		areas.add(new Level(9, "forest", Color.green, 2, forestImage, hedgeImage));
		areas.add(new Level(11, "graveyard", Color.gray, 3,  graveyardImage, gravedoorImage));
		areas.add(new Level(11, "town", brownish, 3,  townImage, townDoorImage));
		areas.add(new Level(13, "castle", brownish, 4,  towerImage, towerDoorImage));
		areas.add(new Level(7, "final", brownish, 1,  towerImage, towerDoorImage));
		
		
		
		
		switchLevel();
		setUP = true;
		Timer clock= new Timer(DELAY_IN_MILLISEC, this);	
		clock.start();


	}
	public void addKeyBindings()
	{
		inputMap.put(KeyStroke.getKeyStroke("SPACE"), "space");
		actionMap.put("space", new keyAction("space"));
		
		inputMap.put(KeyStroke.getKeyStroke("released SPACE"), "released space");
		actionMap.put("released space", new keyAction("released space"));
		//shooting
		inputMap.put(KeyStroke.getKeyStroke("UP"), "up");
		actionMap.put("up", new keyAction("up"));
		
		inputMap.put(KeyStroke.getKeyStroke("DOWN"), "down");
		actionMap.put("down", new keyAction("down"));

		inputMap.put(KeyStroke.getKeyStroke("RIGHT"), "right");
		actionMap.put("right", new keyAction("right"));
		
		inputMap.put(KeyStroke.getKeyStroke("LEFT"), "left");
		actionMap.put("left", new keyAction("left"));
		//movement
		inputMap.put(KeyStroke.getKeyStroke("pressed W"), "w");
		actionMap.put("w", new keyAction("w"));
		
		inputMap.put(KeyStroke.getKeyStroke("pressed A"), "a");
		actionMap.put("a", new keyAction("a"));

		inputMap.put(KeyStroke.getKeyStroke("pressed S"), "s");
		actionMap.put("s", new keyAction("s"));
		
		inputMap.put(KeyStroke.getKeyStroke("pressed D"), "d");
		actionMap.put("d", new keyAction("d"));
		
		inputMap.put(KeyStroke.getKeyStroke("released W"), "released w");
		actionMap.put("released w", new keyAction("released w"));
		
		inputMap.put(KeyStroke.getKeyStroke("released A"), "released a");
		actionMap.put("released a", new keyAction("released a"));
		
		inputMap.put(KeyStroke.getKeyStroke("released S"), "released s");
		actionMap.put("released s", new keyAction("released s"));
		
		inputMap.put(KeyStroke.getKeyStroke("released D"), "released d");
		actionMap.put("released d", new keyAction("released d"));
		//switching spells
		inputMap.put(KeyStroke.getKeyStroke("pressed Q"), "switchleft");
		actionMap.put("switchleft", new keyAction("switchleft"));
		
		inputMap.put(KeyStroke.getKeyStroke("pressed E"), "switchright");
		actionMap.put("switchright", new keyAction("switchright"));
	}
	public void switchLevel()
	{
		if(areasCounter >= areas.size())
		{
			ALIVE = false;
			levelComplete = true;
			return;
		}
		currentLevel = areas.get(areasCounter);
		currentImage = enemyImages.get(areasCounter);
		int counter = currentLevel.getNumCollectibles();
		for(int i = 0; i < counter; i++)
		{
			int k = (int)(Math.random() * collection.size());
			currentLevel.setCollectible(collection.get(k));
			collection.remove(k);
		}
		currentLevel.setUpLevel();
		currentLevel.createDoors();	
		p.xpos = 300;
		p.ypos = 300;
		areasCounter++;
	}
	public void loadImages() throws IOException{
		//enemies
		
		zombieImage = ImageIO.read(new File("./resources/Zombie.png"));
		zombieImage = zombieImage.getScaledInstance(40, 40, 0);
		enemyImages.add(zombieImage);
		skeletonImage = ImageIO.read(new File("./resources/Skeleton.png"));
		skeletonImage = skeletonImage.getScaledInstance(40, 40, 0);
		enemyImages.add(skeletonImage);
		barbarianImage = ImageIO.read(new File("./resources/Barbarian.png"));
		barbarianImage = barbarianImage.getScaledInstance(40, 40, 0);
		enemyImages.add(barbarianImage);
		knightImage = ImageIO.read(new File("./resources/knight.png"));
		knightImage = knightImage.getScaledInstance(40, 40, 0);
		enemyImages.add(knightImage);
		enemyImages.add(knightImage);
		
		//background images
		forestImage = ImageIO.read(new File("./resources/forest.png"));
		forestImage = forestImage.getScaledInstance(500, 500, 0);
		hedgeImage = ImageIO.read(new File("./resources/hedge.png"));
		graveyardImage = ImageIO.read(new File("./resources/Graveyard.png"));
		graveyardImage = graveyardImage.getScaledInstance(500, 500, 0);
		gravedoorImage = ImageIO.read(new File("./resources/graveDoor.png"));
		townImage = ImageIO.read(new File("./resources/town.png"));
		townImage = townImage.getScaledInstance(500, 500, 0);
		townDoorImage = ImageIO.read(new File("./resources/townDoor.png"));
		towerImage = ImageIO.read(new File("./resources/tower.png"));
		towerImage = towerImage.getScaledInstance(500, 500, 0);
		towerDoorImage = ImageIO.read(new File("./resources/towerDoor.png"));
		
		//boss images
		dstandingImage = ImageIO.read(new File("./resources/darkStandingWizard.png"));
		dstandingImage = dstandingImage.getScaledInstance(40, 40, 0);
		dshootingImage = ImageIO.read(new File("./resources/darkShootingWizard.png"));
		dshootingImage = dshootingImage.getScaledInstance(40, 40, 0);
		Boss.standingImage = dstandingImage;
		Boss.shootingImage = dshootingImage;
		
		
	}
	
	public void setUpCollection()
	{
		
		collection.add("healthUP");
		collection.add("healthUP");
		collection.add("healthUP");
		collection.add("DamageUP");
		collection.add("DamageUP");
		collection.add("ManaUP");
		collection.add("ManaUP");
		collection.add("FireRateUP");
		collection.add("FireRateUP");
		collection.add("healthUP + full Heal");
		collection.add("SpeedUP");
		collection.add("SpeedUP");
		collection.add("Heal");
		collection.add("Heal");
		collection.add("Heal");
		collection.add("fireUpgrade");
		collection.add("fireUpgrade");
		collection.add("iceUpgrade");
		collection.add("iceUpgrade");
		collection.add("lightningUpgrade");
		collection.add("lightningUpgrade");
		collection.add("shieldUpgrade");
		collection.add("shieldUpgrade");
		collection.add("superUpgrade (All Stats Up)");
		collection.add("mana Recharge Upgrade");
		collection.add("mana Recharge Upgrade");
		collection.add("mana Drain Down");
	}
	
	
	/*
	public void mouseClicked(MouseEvent e){


	}
	public void mousePressed(MouseEvent e) {

	}
	public void mouseReleased(MouseEvent e) {

	}
	public void mouseEntered(MouseEvent e) {

	}
	public void mouseExited(MouseEvent e) {

	}
	 */


	public void actionPerformed(ActionEvent e)	// NEW #5 !!!!!!!!!!
	{
		//panel.setFocusable(true);
		if(ALIVE){

		//only want to waste time checking a door collision if it isn't cleared
		if(currentLevel.getcurrentRoom().getCleared())
		{
			if(currentLevel.getcurrentRoom().getRoomType() == "reward")
			{
				if(currentLevel.getcurrentRoom().collectibleCollision(p.getXpos(), p.getYpos()))
				{
					p.addItem(currentLevel.getcurrentRoom().getCollectibleName());
				}
			}
			roomChange = currentLevel.doorCollisionR(p.getXpos(), p.getYpos());
			
			if(roomChange != null)
			{
				if(roomChange == "victory")
				{
					roomChange = null;
					switchLevel();
					
				}
				else
				{
				p.enterRoom(roomChange);
				currentLevel.getcurrentRoom().setEnemyDelay();
				roomChange = null;
				}
			}
		}
		if(p.roomInteract(currentLevel.getcurrentRoom())){
			ALIVE = false;
		}
		p.movePlayer();
		
		
		}
		//panel.requestFocusInWindow();
		//this.requestFocusInWindow();

		repaint();
		Toolkit.getDefaultToolkit().sync();
		
		
	}

	public void paint(Graphics g)
	{	
		if(ALIVE){
		//g.drawString("timer = " + timer, 650, 150);
		currentLevel.drawCurrentRoom(g, p, currentImage);
		p.drawPlayer(g);
		}
		else
		{
			if(levelComplete == false)
			{
				g.setColor(Color.red);
				g.fillRect(PLAY_STARTX, PLAY_STARTX, PLAY_WIDTH, PLAY_HEIGHT);
				g.setColor(Color.black);
				g.drawString("You Lose", 280, 300);
			}
			if(levelComplete)
			{
				g.setColor(Color.pink);
				g.fillRect(PLAY_STARTX, PLAY_STARTX, PLAY_WIDTH, PLAY_HEIGHT);
				g.setColor(Color.black);
				g.drawString("You Won", 280, 300);
			}
		}
		f.requestFocus();
		//f.getToolkit().sync();
		//.getBounds().f.addFocusListener(null);

	}
	public void clearScreen(Graphics g)
	{
		g.setColor(Color.white);
		g.fillRect(PLAY_STARTX, PLAY_STARTX, PLAY_WIDTH, PLAY_HEIGHT);
		g.setColor(Color.black);
		g.drawRect(PLAY_STARTX, PLAY_STARTX, PLAY_WIDTH, PLAY_HEIGHT);
	}


}
	class keyAction extends AbstractAction {
		static Player p;
		String key;
		public keyAction(String keyIn){
			key = keyIn;
		}

		public void actionPerformed(ActionEvent arg0) 
		{
	       if(key == "space")
	       {
	    	   p.Shield();
	       }
	       if(key == "released space")
	       {
	    	   p.cancelShield();
	       }
	       if(key == "up")
	       {
	    	   p.shoot("u");
	       }
	       if(key == "down")
	       {
	    	   p.shoot("d");
	       }
	     
	       if(key == "left")
	       {
	    	   p.shoot("l");
	       }

	       if(key == "right")
	       {
	    	   p.shoot("r");
	       }
	       if(key == "w")
	       {
	    	   p.setDirection("u", true);
	       }
	       if(key == "a")
	       {
	    	   p.setDirection("l", true);
	       }
	       if(key == "s")
	       {
	    	   p.setDirection("d", true);
	       }
	       if(key == "d")
	       {
	    	   p.setDirection("r", true);
	       }
	       if(key == "released w")
	       {
	    	   p.setDirection("u", false);
	       }
	       if(key == "released a")
	       {
	    	   p.setDirection("l", false);
	       }
	       if(key == "released s")
	       {
	    	   p.setDirection("d", false);
	       }
	       if(key == "released d")
	       {
	    	   p.setDirection("r", false);
	       }
	       if(key == "switchright")
	       {
	    	   p.selectSpell(1);
	       }
	       if(key == "switchleft")
	       {
	    	   p.selectSpell(-1);
	       }
	       
	       
	      
	    }
	}
